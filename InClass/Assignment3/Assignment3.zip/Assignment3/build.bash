#!/bin/bash
set -u -e
javac Coursework.java Exam.java Student.java Assignment3.java GradePanel.java
