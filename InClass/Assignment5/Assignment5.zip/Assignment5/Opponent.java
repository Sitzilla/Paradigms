class Opponent extends Sprite 
{
    public Opponent(int x, int y, int width, int height) {
        super(x, y, width, height, "AggiesReveille.jpg", 35);
    }
}