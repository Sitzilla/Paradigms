class Razorback extends Sprite 
{
    public Razorback(int x, int y, int width, int height) {
        super(x, y, width, height, "razorback.png", 35);
    }
}