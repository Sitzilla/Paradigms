#!/bin/bash
set -u -e
javac Controller.java Model.java Razorback.java Sprite.java Opponent.java View.java SpriteMover.java
